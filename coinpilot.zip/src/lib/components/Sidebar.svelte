
<nav class="w-60 h-full bg-gray-900 text-white p-4">
  <h1 class="text-xl font-bold mb-4">CoinPilot</h1>
  <ul class="space-y-2">
    <li><a href="/dashboard">🏠 Dashboard</a></li>
    <li><a href="/chart">📈 차트</a></li>
    <li><a href="/performance">📊 수익률</a></li>
    <li><a href="/dataset">🧠 학습데이터</a></li>
    <li><a href="/portfolio">💼 포트폴리오</a></li>
    <li><a href="/strength">🏆 상대강도</a></li>
    <li><a href="/settings">⚙️ 설정</a></li>
  </ul>
</nav>
